<?php
/**
 * Auto generated from dmp.proto at 2015-10-16 19:13:27
 *
 * ad.dmp package
 */

namespace Ad\Dmp {
/**
 * CDeleteCookieSvcReq message
 */
class CDeleteCookieSvcReq extends \ProtobufMessage
{
    /* Field index constants */
    const DWVERSION = 1;
    const DDWTASKID = 2;

    /* @var array Field descriptors */
    protected static $fields = array(
        self::DWVERSION => array(
            'name' => 'dwVersion',
            'required' => true,
            'type' => 5,
        ),
        self::DDWTASKID => array(
            'name' => 'ddwTaskId',
            'required' => true,
            'type' => 5,
        ),
    );

    /**
     * Constructs new message container and clears its internal state
     *
     * @return null
     */
    public function __construct()
    {
        $this->reset();
    }

    /**
     * Clears message values and sets default ones
     *
     * @return null
     */
    public function reset()
    {
        $this->values[self::DWVERSION] = null;
        $this->values[self::DDWTASKID] = null;
    }

    /**
     * Returns field descriptors
     *
     * @return array
     */
    public function fields()
    {
        return self::$fields;
    }

    /**
     * Sets value of 'dwVersion' property
     *
     * @param int $value Property value
     *
     * @return null
     */
    public function setDwVersion($value)
    {
        return $this->set(self::DWVERSION, $value);
    }

    /**
     * Returns value of 'dwVersion' property
     *
     * @return int
     */
    public function getDwVersion()
    {
        return $this->get(self::DWVERSION);
    }

    /**
     * Sets value of 'ddwTaskId' property
     *
     * @param int $value Property value
     *
     * @return null
     */
    public function setDdwTaskId($value)
    {
        return $this->set(self::DDWTASKID, $value);
    }

    /**
     * Returns value of 'ddwTaskId' property
     *
     * @return int
     */
    public function getDdwTaskId()
    {
        return $this->get(self::DDWTASKID);
    }
}
}