<?php
/**
 * Auto generated from dmp.proto at 2015-10-16 19:13:27
 *
 * ad.dmp package
 */

namespace Ad\Dmp {
/**
 * CSyncCookieSvcResp message
 */
class CSyncCookieSvcResp extends \ProtobufMessage
{
    /* Field index constants */
    const DWRET = 1;

    /* @var array Field descriptors */
    protected static $fields = array(
        self::DWRET => array(
            'name' => 'dwRet',
            'required' => true,
            'type' => 5,
        ),
    );

    /**
     * Constructs new message container and clears its internal state
     *
     * @return null
     */
    public function __construct()
    {
        $this->reset();
    }

    /**
     * Clears message values and sets default ones
     *
     * @return null
     */
    public function reset()
    {
        $this->values[self::DWRET] = null;
    }

    /**
     * Returns field descriptors
     *
     * @return array
     */
    public function fields()
    {
        return self::$fields;
    }

    /**
     * Sets value of 'dwRet' property
     *
     * @param int $value Property value
     *
     * @return null
     */
    public function setDwRet($value)
    {
        return $this->set(self::DWRET, $value);
    }

    /**
     * Returns value of 'dwRet' property
     *
     * @return int
     */
    public function getDwRet()
    {
        return $this->get(self::DWRET);
    }
}
}