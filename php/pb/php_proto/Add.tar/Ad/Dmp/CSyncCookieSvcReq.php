<?php
/**
 * Auto generated from dmp.proto at 2015-10-16 19:13:27
 *
 * ad.dmp package
 */

namespace Ad\Dmp {
/**
 * CSyncCookieSvcReq message
 */
class CSyncCookieSvcReq extends \ProtobufMessage
{
    /* Field index constants */
    const DWVERSION = 1;
    const STASKID = 2;

    /* @var array Field descriptors */
    protected static $fields = array(
        self::DWVERSION => array(
            'name' => 'dwVersion',
            'required' => true,
            'type' => 5,
        ),
        self::STASKID => array(
            'name' => 'sTaskId',
            'required' => true,
            'type' => 7,
        ),
    );

    /**
     * Constructs new message container and clears its internal state
     *
     * @return null
     */
    public function __construct()
    {
        $this->reset();
    }

    /**
     * Clears message values and sets default ones
     *
     * @return null
     */
    public function reset()
    {
        $this->values[self::DWVERSION] = null;
        $this->values[self::STASKID] = null;
    }

    /**
     * Returns field descriptors
     *
     * @return array
     */
    public function fields()
    {
        return self::$fields;
    }

    /**
     * Sets value of 'dwVersion' property
     *
     * @param int $value Property value
     *
     * @return null
     */
    public function setDwVersion($value)
    {
        return $this->set(self::DWVERSION, $value);
    }

    /**
     * Returns value of 'dwVersion' property
     *
     * @return int
     */
    public function getDwVersion()
    {
        return $this->get(self::DWVERSION);
    }

    /**
     * Sets value of 'sTaskId' property
     *
     * @param string $value Property value
     *
     * @return null
     */
    public function setSTaskId($value)
    {
        return $this->set(self::STASKID, $value);
    }

    /**
     * Returns value of 'sTaskId' property
     *
     * @return string
     */
    public function getSTaskId()
    {
        return $this->get(self::STASKID);
    }
}
}