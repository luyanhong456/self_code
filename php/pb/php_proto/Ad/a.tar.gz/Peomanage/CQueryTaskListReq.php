<?php
/**
 * Auto generated from jtdmp_peomanage.proto at 2016-03-10 20:32:05
 *
 * ad.peomanage package
 */

namespace Ad\Peomanage {
/**
 * CQueryTaskListReq message
 */
class CQueryTaskListReq extends \ProtobufMessage
{
    /* Field index constants */
    const SELLERPIN = 1;

    /* @var array Field descriptors */
    protected static $fields = array(
        self::SELLERPIN => array(
            'name' => 'sellerpin',
            'required' => true,
            'type' => 7,
        ),
    );

    /**
     * Constructs new message container and clears its internal state
     *
     * @return null
     */
    public function __construct()
    {
        $this->reset();
    }

    /**
     * Clears message values and sets default ones
     *
     * @return null
     */
    public function reset()
    {
        $this->values[self::SELLERPIN] = null;
    }

    /**
     * Returns field descriptors
     *
     * @return array
     */
    public function fields()
    {
        return self::$fields;
    }

    /**
     * Sets value of 'sellerpin' property
     *
     * @param string $value Property value
     *
     * @return null
     */
    public function setSellerpin($value)
    {
        return $this->set(self::SELLERPIN, $value);
    }

    /**
     * Returns value of 'sellerpin' property
     *
     * @return string
     */
    public function getSellerpin()
    {
        return $this->get(self::SELLERPIN);
    }
}
}